// La función init detecta cuando se ha apretado el botón para comprobar que la contraseña sea correcta

function init(){
    let button = document.getElementById("send");
    button.addEventListener("click", checkPasswordErrors);
}

// Se encarga de detectar si la contraseña tiene algún error

function checkPasswordErrors(){

    let passwordHasErrors = false;
    let password = document.getElementById("password").value;
    let showMessages = document.getElementById("showMessages");
    showMessages.innerHTML = '';


    // -- COMPROBACIÓN DE ERRORES --

    // Comprueba que tenga entre 8 y 20 charácteres
    if(!checkLength(password.length)){
        passwordHasErrors = true;
        showTextMessage('La contraseña tiene que tener entre 8 y 20 carácteres.', passwordHasErrors);
    }

    // Comprueba que tenga una mayúscula
    if(!checkUpperLetters(password)){
        passwordHasErrors = true;
        showTextMessage('La contraseña tiene que tener al menos una mayúscula.', passwordHasErrors);
    }

    // Comprueba que tenga dos minúsculas
    if(!checkLowerLetters(password)){
        passwordHasErrors = true;
        showTextMessage('La contraseña tiene que tener al menos dos minúsculas.', passwordHasErrors);
    }

    // Comprueba que tenga un dígito
    if(!checkDigits(password)){
        passwordHasErrors = true;
        showTextMessage('La contraseña tiene que tener al menos un dígito.', passwordHasErrors);
    }

    // Comprueba que tenga tres carácteres iguales seguidos
    if(threeConsecutiveLetters(password)){
        passwordHasErrors = true;
        showTextMessage('La contraseña no puede tener tres o más carácteres iguales seguidos', passwordHasErrors);
    }

    // Comprueba que no contenga espacios
    if(containsSpaces(password)){
        passwordHasErrors = true;
        showTextMessage('La contraseña no puede tener espacios en blanco', passwordHasErrors);
    }

    // Comprueba que tenga un carácter especial 
    if(!checkSpecialChars(password)){
        passwordHasErrors = true;
        showTextMessage('La contraseña tiene que tener al menos un carácter especial', passwordHasErrors);
    }


    // -- MENSAJE DE OK --

    if(!passwordHasErrors){
        showTextMessage('La contraseña es válida', passwordHasErrors);
    }

}


// Muestra el texto que se introduce en textMessage y cambia el estilo dependiendo de si es un mensaje de error o no

function showTextMessage(textMessage, passwordHasErrors){

    let showMessages = document.getElementById("showMessages");
    let passwordMessage = document.createElement('p');
    let errorText = document.createTextNode(textMessage);

    if(passwordHasErrors) passwordMessage.className = 'errorMessage';
    else passwordMessage.className = 'successMessage';
    

    passwordMessage.appendChild(errorText);
    showMessages.appendChild(passwordMessage);

}

// Comprueba que una cadena tenga entre 8 y 20 carácteres

function checkLength(stringLength){
    return (stringLength >= 8 && stringLength <= 20);
}

// Comprueba que la cadena tenga al menos una mayúsculas
function checkUpperLetters(password){
    return quantUpperLetters(password) >= 1;
}

// Comprueba que la cadena tenga al menos dos minúsculas
function checkLowerLetters(password){
    return quantLowerLetters(password) >= 2;
}

// Comprueba que la cadena tenga al menos un dígito

function checkDigits(password){
    return quantDigits(password) >= 1;
}

// Comprueba que la cadena tenga al menos un carácter especial

function checkSpecialChars(password){
    return quantSpecialCharacters(password) >= 1;
}

// Comprueba si la cadena contiene espacios

function containsSpaces(password){
    return password.includes(" ");
}

// Comprueba el número de mayúsculas que tiene una cadena

function quantUpperLetters(password){

    let upperLettersCount = 0;
    let upperLetters = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";

    for(let i = 0; i < password.length; i++){
        if(upperLetters.includes(password[i])){
            upperLettersCount++;
        }
    }

    return upperLettersCount;
}


// Comprueba el número de minúsculas que tiene una cadena

function quantLowerLetters(password){
    
        let lowerLettersCount = 0;
        
        let lowerLetters = "abcdefghijklmnñopqrstuvwxyz";

        for(let i = 0; i < password.length; i++){
    
            if(lowerLetters.includes(password[i])){
                lowerLettersCount++;
            }
        }
        return lowerLettersCount;
}

// Comprueba el número de dígitos que tiene una cadena

function quantDigits(password){

    let digits = 0;
    let numbers = "0123456789";

    for(let i = 0; i < password.length; i++){

        if(numbers.includes(password[i])){
            digits++;
        }

    }

    return digits;

}

// Comprueba si hay tres carácteres iguales seguidos

function threeConsecutiveLetters(password){

    for(let i = 0; i < password.length-2; i++){

        if(password[i] == password[i + 1] && password[i] == password[i + 2]){
            return true;
        }

    }

    return false;
}

// Comprueba cuantos carácteres especiales tiene la cadena

function quantSpecialCharacters(password){

    let specialCharactersCount = 0;
    let specialCharacters = "!@#$%^&*()-+";

    for(let i = 0; i < password.length; i++){
        if(specialCharacters.includes(password[i])){
            specialCharactersCount++;
        }
    }

    return specialCharactersCount;
}




// Esta parte del código es adicional, implementa la opción de ocultar o mostrar la contraseña y está hecha mediante chatgpt (aunque entiendo lo que hace y la he modificado)

function togglePassword() {
    var passwordInput = document.getElementById("password");
    var toggleBtn = document.getElementById("toggleBtn");
    var labelShowPassword = document.getElementById("labelShowPassword");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        labelShowPassword.textContent = "Ocultar contraseña";
    } else {
        passwordInput.type = "password";
        labelShowPassword.textContent = "Mostrar contraseña";
    }

}